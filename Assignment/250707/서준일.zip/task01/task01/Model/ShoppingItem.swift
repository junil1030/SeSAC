//
//  ShoppingItem.swift
//  task01
//
//  Created by 서준일 on 7/10/25.
//

import Foundation

struct ShoppingItem {
    let name: String
    var isFavorite: Bool = false
    var isPurchased: Bool = false
}
