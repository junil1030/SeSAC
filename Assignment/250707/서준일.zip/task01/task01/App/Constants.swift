//
//  Constants.swift
//  task01
//
//  Created by 서준일 on 7/8/25.
//

import UIKit

struct Constants {
    static let baseColor: UIColor = UIColor(red: 77/255, green: 106/255, blue: 120/255, alpha: 1)
}
